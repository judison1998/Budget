package com.example.budget.database

import android.app.Application
import android.content.Context
import androidx.fragment.app.Fragment
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.budget.fragments.AllFragment
import com.google.android.material.internal.ContextUtils.getActivity


@Database(entities = [BudgetItem::class , CartItem::class],version = 4)
abstract class BudgetDatabase : RoomDatabase() {
    abstract fun budgetDao() : BugetDao

    companion object {
        @Volatile
        private var INSTANCE : BudgetDatabase? = null

        fun getInstance(context: Context) : BudgetDatabase {
            var instance = INSTANCE

            if (instance != null) {
                return instance
            }
            synchronized(this){
                val instance = Room.databaseBuilder(context,
                    BudgetDatabase::class.java,"budget_database")
                    .fallbackToDestructiveMigration()
                    .allowMainThreadQueries()
                    .build()
                INSTANCE = instance
                return instance
            }
        }

    }
}