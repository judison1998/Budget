package com.example.budget

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.appcompat.widget.Toolbar
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import androidx.fragment.app.FragmentTransaction
import androidx.lifecycle.Observer
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.NavigationUI.setupActionBarWithNavController
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager.widget.ViewPager
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
//import androidx.viewpager2.widget.ViewPager2
import com.example.budget.account.ProfileActivity
import com.example.budget.database.BudgetDatabase
import com.example.budget.database.BudgetItem
import com.example.budget.databinding.ActivityListBinding
//import com.example.budget.databinding.ActivityListBinding
import com.example.budget.fragments.*
import com.example.budget.network.IshopNetwork
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class ListActivity : AppCompatActivity() {

    lateinit var bottomNav: BottomNavigationView

    lateinit var budgetAdapter: BudgetAdapter

    lateinit var itemList: ArrayList<BudgetItem>
//    private lateinit var pager: ViewPager
//    private lateinit var tab: TabLayout
//    private lateinit var toolbar: Toolbar

    var tabLayout: TabLayout? = null
    var frameLayout: FrameLayout? = null
    var fragment: Fragment? = null
    var fragmentManager: FragmentManager? = null
    var fragmentTransaction: FragmentTransaction? = null


    lateinit var navController: NavController
    private lateinit var binding: ActivityListBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityListBinding.inflate(layoutInflater)
        setContentView(binding.root)


        tabLayout = findViewById<TabLayout>(R.id.tabs)
        frameLayout = findViewById<FrameLayout>(R.id.frame_layout)

        fragment = AllFragment()
        fragmentManager = supportFragmentManager
        fragmentTransaction = fragmentManager!!.beginTransaction()
        fragmentTransaction!!.replace(R.id.frame_layout, fragment!!)
        fragmentTransaction!!.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
        fragmentTransaction!!.commit()
        //adding listener for tab select
        tabLayout!!.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                // creating cases for fragment
                when (tab.position) {
                    0 -> fragment = AllFragment()
                    1 -> fragment = MenFragment()
                    2 -> fragment = WomenFragment()
                    3 -> fragment = KidsFragment()
                    else -> fragment = AllFragment()
                }
                val fm = supportFragmentManager
                val ft = fm.beginTransaction()
                ft.replace(R.id.frame_layout, fragment!!)
                ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                ft.commit()
            }

            override fun onTabUnselected(tab: TabLayout.Tab) {

            }

            override fun onTabReselected(tab: TabLayout.Tab) {

            }
        })













//
//        val adapter=ViewPagerAdapter(supportFragmentManager)
//        adapter.addFragment(AllFragment(),"All")
//        adapter.addFragment(MenFragment(),"Men")
//        adapter.addFragment(WomenFragment(),"Women")
//        adapter.addFragment(KidsFragment(),"Kids")
//        binding.viewPager.adapter=adapter
//        binding.tabs.setupWithViewPager(binding.viewPager)

//        replaceFragment(AllFragment())

//        val navHostFragment = supportFragmentManager
//            .findFragmentById(R.id.my_nav_host_fragment) as NavHostFragment
//        navController = navHostFragment.navController
//        setupActionBarWithNavController(navController)
//        toolbar = findViewById(R.id.toolbar)
//        val tabLayout = findViewById<TabLayout>(R.id.tabs)
//        val viewPager = findViewById<ViewPager2>(R.id.viewPager)
//        viewPager.adapter = FragmentAdapter(this)
//        TabLayoutMediator(tabLayout, viewPager){tab, position ->
//            tab.text = "Tab ${position}"
//        }.attach()
//        setSupportActionBar(bar)

//        val adapter = ViewPagerAdapter(supportFragmentManager)
//
//        adapter.addFragment(AllFragment(), "All")
//        adapter.addFragment(MenFragment(), "Men")
//        adapter.addFragment(WomenFragment(), "Women")
//        adapter.addFragment(KidsFragment(), "Kids")
//        pager.adapter = adapter
//        tab.setupWithViewPager(pager)
        bottomNav = findViewById(R.id.bottomNav)

        bottomNav = findViewById(R.id.bottomNav)


        bottomNav?.setOnItemSelectedListener {
            when (it.itemId) {
                R.id.home -> {
                    val i = Intent(this, ListActivity::class.java)
                    startActivity(i)
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.profile -> {
                    val i = Intent(this, ProfileActivity::class.java)
                    startActivity(i)
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.help -> {
                    val i = Intent(this, HelpActivity::class.java)
                    startActivity(i)
                    finish()
                    return@setOnItemSelectedListener true
                }
                else -> {
                    return@setOnItemSelectedListener true
                }
            }
        }
    }

//    private fun replaceFragment(allFragment: Fragment) {
//        val fragmentManager = supportFragmentManager
//        val fragmentTransaction = fragmentManager.beginTransaction().add(R.id.frame_layout,AllFragment())
//        fragmentTransaction.replace(R.id.frame_layout,allFragment)
//        fragmentTransaction.commit()
//    }
    override fun onSupportNavigateUp(): Boolean {
        return navController.navigateUp() || super.onSupportNavigateUp()
    }
    class ViewPagerAdapter(fm : FragmentManager) : FragmentStatePagerAdapter(fm){
        private val mFrgmentList = ArrayList<Fragment>()
        private val mFrgmentTitleList = ArrayList<String>()
        override fun getCount() = mFrgmentList.size
        override fun getItem(position: Int) = mFrgmentList[position]
        override fun getPageTitle(position: Int) = mFrgmentTitleList[position]
        fun addFragment(fragment:Fragment,title:String){
            mFrgmentList.add(fragment)
            mFrgmentTitleList.add(title)
        }
    }

//    class FragmentAdapter(activity: AppCompatActivity) : FragmentStateAdapter(activity) {
//        override fun getItemCount(): Int {
//            return 4
//        }
//
//        override fun createFragment(position: Int): Fragment {
//            return when (position) {
//                0 -> AllFragment.newInstance()
//                1 -> MenFragment.newInstance()
//                2 -> WomenFragment.newInstance()
//                3 -> KidsFragment.newInstance()
//                else -> AllFragment.newInstance()
//            }
//        }
//    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.search_menu, menu)
        val searchItem: MenuItem = menu!!.findItem(R.id.actionSearch)
        val searchView: SearchView = searchItem.getActionView() as SearchView
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener,
            android.widget.SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(p0: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(msg: String): Boolean {
                filter(msg)
                return false
            }

        })
        return true

    }

    private fun filter(text: String) {
        val filteredlist: ArrayList<BudgetItem> = ArrayList()

        for (item in itemList) {
            if (item.productName.toLowerCase().contains(text.toLowerCase())) {
                filteredlist.add(item)
            }
        }
        if (filteredlist.isEmpty()) {
            Toast.makeText(this, "No Data Found..", Toast.LENGTH_SHORT).show()
        } else {
            budgetAdapter.filterList(filteredlist)
        }
    }

}