package com.example.budget.network

//import com.squareup.moshi.Json

//data class Products (
//
//    @Json(name = "product_id")
//    var productID: Int,
//
//    @Json(name = "product_name")
//    var productName: String,
//
//    @Json(name = "product_price")
//    var productPrice: String,
//
//    @Json(name = "product_image")
//    var productImage: String
//
//         )
