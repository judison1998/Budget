package com.example.budget

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class KidsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_kids)
    }
}